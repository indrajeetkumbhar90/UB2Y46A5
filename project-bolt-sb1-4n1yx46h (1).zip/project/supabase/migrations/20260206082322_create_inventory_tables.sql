/*
  # Smart Inventory Management System

  ## 1. New Tables
    
  ### `products`
  - `id` (uuid, primary key) - Unique product identifier
  - `name` (text) - Product name
  - `sku` (text, unique) - Stock Keeping Unit code
  - `current_stock` (integer) - Current inventory level
  - `min_stock_level` (integer) - Minimum stock threshold for alerts
  - `max_stock_level` (integer) - Maximum stock capacity
  - `unit_price` (decimal) - Price per unit
  - `category` (text) - Product category
  - `supplier` (text) - Supplier name
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### `inventory_history`
  - `id` (uuid, primary key) - Unique record identifier
  - `product_id` (uuid, foreign key) - Reference to products table
  - `quantity_change` (integer) - Change in stock (positive or negative)
  - `stock_after` (integer) - Stock level after change
  - `transaction_type` (text) - Type of transaction (sale, restock, adjustment)
  - `notes` (text) - Optional notes about the transaction
  - `created_at` (timestamptz) - Transaction timestamp

  ## 2. Security
  - Enable RLS on both tables
  - Add policies for authenticated users to read all data
  - Add policies for authenticated users to insert/update inventory records
  
  ## 3. Indexes
  - Add index on product SKU for fast lookups
  - Add index on inventory_history product_id and created_at for forecasting queries
*/

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  sku text UNIQUE NOT NULL,
  current_stock integer NOT NULL DEFAULT 0,
  min_stock_level integer NOT NULL DEFAULT 10,
  max_stock_level integer NOT NULL DEFAULT 100,
  unit_price decimal(10, 2) NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT 'General',
  supplier text NOT NULL DEFAULT 'Unknown',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create inventory_history table
CREATE TABLE IF NOT EXISTS inventory_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity_change integer NOT NULL,
  stock_after integer NOT NULL,
  transaction_type text NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku);
CREATE INDEX IF NOT EXISTS idx_inventory_history_product_date ON inventory_history(product_id, created_at DESC);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_history ENABLE ROW LEVEL SECURITY;

-- Products policies
CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert products"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update products"
  ON products FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete products"
  ON products FOR DELETE
  TO authenticated
  USING (true);

-- Inventory history policies
CREATE POLICY "Anyone can view inventory history"
  ON inventory_history FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert inventory history"
  ON inventory_history FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update inventory history"
  ON inventory_history FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete inventory history"
  ON inventory_history FOR DELETE
  TO authenticated
  USING (true);