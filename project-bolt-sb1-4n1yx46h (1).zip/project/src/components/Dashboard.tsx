import { useState, useEffect } from 'react';
import { Package, TrendingUp, Calculator, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Product } from '../types/database';
import ProductList from './ProductList';
import DemandForecast from './DemandForecast';
import WhatIfSimulation from './WhatIfSimulation';

type ViewType = 'products' | 'forecast' | 'simulation';

export default function Dashboard() {
  const [currentView, setCurrentView] = useState<ViewType>('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [lowStockCount, setLowStockCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('name');

      if (error) throw error;

      setProducts(data || []);
      const lowStock = data?.filter(p => p.current_stock <= p.min_stock_level).length || 0;
      setLowStockCount(lowStock);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalValue = products.reduce((sum, p) => sum + (p.current_stock * p.unit_price), 0);
  const totalProducts = products.length;
  const totalStock = products.reduce((sum, p) => sum + p.current_stock, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Inventory Management</h1>
          <p className="text-slate-600">Monitor stock levels, forecast demand, and optimize inventory</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900">{totalProducts}</div>
            <div className="text-sm text-slate-600">Total Products</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900">{totalStock}</div>
            <div className="text-sm text-slate-600">Total Units</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <Calculator className="w-6 h-6 text-emerald-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900">${totalValue.toFixed(2)}</div>
            <div className="text-sm text-slate-600">Inventory Value</div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900">{lowStockCount}</div>
            <div className="text-sm text-slate-600">Low Stock Alerts</div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="border-b border-slate-200">
            <nav className="flex -mb-px">
              <button
                onClick={() => setCurrentView('products')}
                className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  currentView === 'products'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                Product Inventory
              </button>
              <button
                onClick={() => setCurrentView('forecast')}
                className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  currentView === 'forecast'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                Demand Forecast
              </button>
              <button
                onClick={() => setCurrentView('simulation')}
                className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  currentView === 'simulation'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                What-If Simulation
              </button>
            </nav>
          </div>

          <div className="p-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <>
                {currentView === 'products' && (
                  <ProductList products={products} onUpdate={loadProducts} />
                )}
                {currentView === 'forecast' && <DemandForecast products={products} />}
                {currentView === 'simulation' && <WhatIfSimulation products={products} />}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
