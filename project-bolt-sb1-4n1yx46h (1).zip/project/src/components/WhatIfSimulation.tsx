import { useState } from 'react';
import { Calculator, AlertCircle } from 'lucide-react';
import type { Product } from '../types/database';

interface WhatIfSimulationProps {
  products: Product[];
}

interface SimulationResult {
  daysOfStock: number;
  reorderDate: string;
  stockoutDate: string;
  recommendedOrderQty: number;
  totalCost: number;
  warnings: string[];
}

export default function WhatIfSimulation({ products }: WhatIfSimulationProps) {
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [dailyDemand, setDailyDemand] = useState<number>(5);
  const [leadTime, setLeadTime] = useState<number>(7);
  const [safetyStock, setSafetyStock] = useState<number>(20);
  const [orderQuantity, setOrderQuantity] = useState<number>(100);
  const [result, setResult] = useState<SimulationResult | null>(null);

  const runSimulation = () => {
    const product = products.find(p => p.id === selectedProduct);
    if (!product) return;

    const warnings: string[] = [];
    const currentStock = product.current_stock;

    const demandDuringLeadTime = dailyDemand * leadTime;
    const totalNeededStock = demandDuringLeadTime + safetyStock;

    const daysOfStock = currentStock > 0 ? Math.floor(currentStock / dailyDemand) : 0;

    const reorderPoint = currentStock - demandDuringLeadTime;
    const daysUntilReorder = reorderPoint > 0 ? Math.floor(reorderPoint / dailyDemand) : 0;

    const stockoutPoint = currentStock - totalNeededStock;
    const daysUntilStockout = stockoutPoint > 0
      ? Math.floor(stockoutPoint / dailyDemand)
      : Math.floor(currentStock / dailyDemand);

    const today = new Date();
    const reorderDate = new Date(today);
    reorderDate.setDate(today.getDate() + Math.max(0, daysUntilReorder));

    const stockoutDate = new Date(today);
    stockoutDate.setDate(today.getDate() + daysUntilStockout);

    const totalCost = orderQuantity * product.unit_price;

    if (currentStock < totalNeededStock) {
      warnings.push('Current stock is below safety levels. Order immediately!');
    }

    if (orderQuantity < demandDuringLeadTime) {
      warnings.push('Order quantity may not be sufficient to cover demand during lead time.');
    }

    if (daysOfStock < leadTime) {
      warnings.push(`Stock will run out before new order arrives (${leadTime} days lead time).`);
    }

    if (orderQuantity > product.max_stock_level - currentStock) {
      warnings.push('Order quantity exceeds available storage capacity.');
    }

    const economicOrderQty = Math.ceil(dailyDemand * 30);

    setResult({
      daysOfStock,
      reorderDate: reorderDate.toLocaleDateString(),
      stockoutDate: stockoutDate.toLocaleDateString(),
      recommendedOrderQty: economicOrderQty,
      totalCost,
      warnings
    });
  };

  const selectedProductData = products.find(p => p.id === selectedProduct);

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <Calculator className="w-12 h-12 text-slate-400 mx-auto mb-3" />
        <p className="text-slate-600">No products available for simulation.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-2">What-If Simulation</h2>
        <p className="text-sm text-slate-600">
          Adjust parameters below to simulate different inventory scenarios and optimize your stock levels.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Select Product
            </label>
            <select
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Choose a product...</option>
              {products.map((product) => (
                <option key={product.id} value={product.id}>
                  {product.name} ({product.sku}) - Current: {product.current_stock}
                </option>
              ))}
            </select>
          </div>

          {selectedProductData && (
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <div className="text-sm text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span>Current Stock:</span>
                  <span className="font-semibold text-slate-900">
                    {selectedProductData.current_stock} units
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Min/Max Levels:</span>
                  <span className="font-semibold text-slate-900">
                    {selectedProductData.min_stock_level} / {selectedProductData.max_stock_level}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Unit Price:</span>
                  <span className="font-semibold text-slate-900">
                    ${selectedProductData.unit_price.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Daily Demand (units/day)
            </label>
            <input
              type="number"
              value={dailyDemand}
              onChange={(e) => setDailyDemand(parseFloat(e.target.value) || 0)}
              min="0"
              step="0.5"
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Lead Time (days)
            </label>
            <input
              type="number"
              value={leadTime}
              onChange={(e) => setLeadTime(parseInt(e.target.value) || 0)}
              min="0"
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Safety Stock (units)
            </label>
            <input
              type="number"
              value={safetyStock}
              onChange={(e) => setSafetyStock(parseInt(e.target.value) || 0)}
              min="0"
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Order Quantity (units)
            </label>
            <input
              type="number"
              value={orderQuantity}
              onChange={(e) => setOrderQuantity(parseInt(e.target.value) || 0)}
              min="0"
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <button
            onClick={runSimulation}
            disabled={!selectedProduct}
            className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
          >
            Run Simulation
          </button>
        </div>

        <div className="space-y-4">
          {result ? (
            <>
              <div className="bg-white rounded-lg border border-slate-200 p-6">
                <h3 className="text-sm font-semibold text-slate-900 mb-4">Simulation Results</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-slate-100">
                    <span className="text-sm text-slate-600">Days of Stock Remaining</span>
                    <span className="text-lg font-bold text-slate-900">{result.daysOfStock}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-slate-100">
                    <span className="text-sm text-slate-600">Recommended Reorder Date</span>
                    <span className="text-sm font-semibold text-slate-900">{result.reorderDate}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-slate-100">
                    <span className="text-sm text-slate-600">Estimated Stockout Date</span>
                    <span className="text-sm font-semibold text-red-600">{result.stockoutDate}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 border-b border-slate-100">
                    <span className="text-sm text-slate-600">Recommended Order Quantity</span>
                    <span className="text-lg font-bold text-blue-600">
                      {result.recommendedOrderQty} units
                    </span>
                  </div>
                  <div className="flex justify-between items-center py-2">
                    <span className="text-sm text-slate-600">Total Order Cost</span>
                    <span className="text-lg font-bold text-green-600">
                      ${result.totalCost.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {result.warnings.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-amber-900 mb-2">Warnings</h4>
                      <ul className="space-y-1">
                        {result.warnings.map((warning, index) => (
                          <li key={index} className="text-sm text-amber-800">
                            • {warning}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="text-sm font-semibold text-blue-900 mb-2">Insights</h4>
                <ul className="space-y-1 text-sm text-blue-800">
                  <li>
                    • At {dailyDemand} units/day, you'll use {(dailyDemand * 30).toFixed(0)} units in 30 days
                  </li>
                  <li>
                    • Lead time buffer needed: {(dailyDemand * leadTime).toFixed(0)} units
                  </li>
                  <li>
                    • Total safety stock: {safetyStock} units ({(safetyStock / dailyDemand).toFixed(1)} days of demand)
                  </li>
                  {selectedProductData && (
                    <li>
                      • Order cost efficiency: {((result.totalCost / orderQuantity)).toFixed(2)} per unit
                    </li>
                  )}
                </ul>
              </div>
            </>
          ) : (
            <div className="bg-slate-50 rounded-lg border-2 border-dashed border-slate-300 p-12 text-center">
              <Calculator className="w-12 h-12 text-slate-400 mx-auto mb-3" />
              <p className="text-slate-600">Select a product and run simulation to see results</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
