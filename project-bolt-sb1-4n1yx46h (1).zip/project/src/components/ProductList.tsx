import { useState } from 'react';
import { AlertTriangle, TrendingUp, TrendingDown, Package } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Product } from '../types/database';

interface ProductListProps {
  products: Product[];
  onUpdate: () => void;
}

export default function ProductList({ products, onUpdate }: ProductListProps) {
  const [updatingProduct, setUpdatingProduct] = useState<string | null>(null);
  const [stockChange, setStockChange] = useState<{ [key: string]: number }>({});

  const getStockStatus = (product: Product) => {
    const percentage = (product.current_stock / product.max_stock_level) * 100;
    if (product.current_stock <= product.min_stock_level) {
      return { label: 'Critical', color: 'bg-red-100 text-red-800 border-red-200', icon: AlertTriangle };
    } else if (percentage < 30) {
      return { label: 'Low', color: 'bg-amber-100 text-amber-800 border-amber-200', icon: TrendingDown };
    } else if (percentage > 80) {
      return { label: 'High', color: 'bg-green-100 text-green-800 border-green-200', icon: TrendingUp };
    }
    return { label: 'Optimal', color: 'bg-blue-100 text-blue-800 border-blue-200', icon: Package };
  };

  const updateStock = async (product: Product, change: number) => {
    if (change === 0) return;

    setUpdatingProduct(product.id);
    try {
      const newStock = Math.max(0, product.current_stock + change);

      const { error: productError } = await supabase
        .from('products')
        .update({
          current_stock: newStock,
          updated_at: new Date().toISOString()
        })
        .eq('id', product.id);

      if (productError) throw productError;

      const { error: historyError } = await supabase
        .from('inventory_history')
        .insert({
          product_id: product.id,
          quantity_change: change,
          stock_after: newStock,
          transaction_type: change > 0 ? 'restock' : 'sale',
          notes: `${change > 0 ? 'Added' : 'Removed'} ${Math.abs(change)} units`
        });

      if (historyError) throw historyError;

      setStockChange({ ...stockChange, [product.id]: 0 });
      onUpdate();
    } catch (error) {
      console.error('Error updating stock:', error);
      alert('Failed to update stock. Please try again.');
    } finally {
      setUpdatingProduct(null);
    }
  };

  const sortedProducts = [...products].sort((a, b) => {
    const aLow = a.current_stock <= a.min_stock_level;
    const bLow = b.current_stock <= b.min_stock_level;
    if (aLow && !bLow) return -1;
    if (!aLow && bLow) return 1;
    return a.name.localeCompare(b.name);
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-900">Product Inventory</h2>
        <div className="text-sm text-slate-600">{products.length} products</div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-200">
              <th className="text-left py-3 px-4 text-sm font-semibold text-slate-700">Product</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-slate-700">SKU</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-slate-700">Category</th>
              <th className="text-center py-3 px-4 text-sm font-semibold text-slate-700">Current Stock</th>
              <th className="text-center py-3 px-4 text-sm font-semibold text-slate-700">Min/Max</th>
              <th className="text-left py-3 px-4 text-sm font-semibold text-slate-700">Status</th>
              <th className="text-right py-3 px-4 text-sm font-semibold text-slate-700">Unit Price</th>
              <th className="text-center py-3 px-4 text-sm font-semibold text-slate-700">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {sortedProducts.map((product) => {
              const status = getStockStatus(product);
              const StatusIcon = status.icon;
              const isUpdating = updatingProduct === product.id;
              const change = stockChange[product.id] || 0;

              return (
                <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-4 px-4">
                    <div className="font-medium text-slate-900">{product.name}</div>
                    <div className="text-sm text-slate-500">{product.supplier}</div>
                  </td>
                  <td className="py-4 px-4 text-sm text-slate-600 font-mono">{product.sku}</td>
                  <td className="py-4 px-4">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">
                      {product.category}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <div className="text-lg font-semibold text-slate-900">{product.current_stock}</div>
                  </td>
                  <td className="py-4 px-4 text-center text-sm text-slate-600">
                    {product.min_stock_level} / {product.max_stock_level}
                  </td>
                  <td className="py-4 px-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border ${status.color}`}>
                      <StatusIcon className="w-3 h-3" />
                      {status.label}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right font-medium text-slate-900">
                    ${product.unit_price.toFixed(2)}
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center justify-center gap-2">
                      <input
                        type="number"
                        value={change}
                        onChange={(e) => setStockChange({ ...stockChange, [product.id]: parseInt(e.target.value) || 0 })}
                        className="w-16 px-2 py-1 text-sm border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="0"
                        disabled={isUpdating}
                      />
                      <button
                        onClick={() => updateStock(product, change)}
                        disabled={isUpdating || change === 0}
                        className="px-3 py-1 text-sm font-medium text-white bg-blue-600 rounded hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
                      >
                        {isUpdating ? '...' : 'Update'}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {products.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <p className="text-slate-600">No products found. Add some products to get started.</p>
        </div>
      )}
    </div>
  );
}
