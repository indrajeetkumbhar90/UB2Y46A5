import { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Product, InventoryHistory } from '../types/database';

interface DemandForecastProps {
  products: Product[];
}

interface ForecastData {
  product: Product;
  history: InventoryHistory[];
  avgDailyChange: number;
  trend: 'up' | 'down' | 'stable';
  daysUntilReorder: number;
  forecastedStock: number[];
}

export default function DemandForecast({ products }: DemandForecastProps) {
  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [forecastData, setForecastData] = useState<ForecastData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (products.length > 0 && !selectedProduct) {
      setSelectedProduct(products[0].id);
    }
  }, [products, selectedProduct]);

  useEffect(() => {
    if (selectedProduct) {
      loadForecast(selectedProduct);
    }
  }, [selectedProduct]);

  const loadForecast = async (productId: string) => {
    setLoading(true);
    try {
      const product = products.find(p => p.id === productId);
      if (!product) return;

      const { data: history, error } = await supabase
        .from('inventory_history')
        .select('*')
        .eq('product_id', productId)
        .order('created_at', { ascending: false })
        .limit(30);

      if (error) throw error;

      const salesHistory = (history || []).filter(h => h.transaction_type === 'sale');

      let avgDailyChange = 0;
      if (salesHistory.length > 0) {
        const totalChange = salesHistory.reduce((sum, h) => sum + Math.abs(h.quantity_change), 0);
        avgDailyChange = totalChange / Math.max(salesHistory.length, 1);
      } else {
        avgDailyChange = 2;
      }

      const trend = avgDailyChange > 3 ? 'up' : avgDailyChange < 1 ? 'down' : 'stable';

      const daysUntilReorder = avgDailyChange > 0
        ? Math.floor((product.current_stock - product.min_stock_level) / avgDailyChange)
        : 999;

      const forecastedStock: number[] = [];
      let currentStock = product.current_stock;
      for (let i = 0; i < 14; i++) {
        currentStock = Math.max(0, currentStock - avgDailyChange);
        forecastedStock.push(currentStock);
      }

      setForecastData({
        product,
        history: history || [],
        avgDailyChange,
        trend,
        daysUntilReorder: Math.max(0, daysUntilReorder),
        forecastedStock
      });
    } catch (error) {
      console.error('Error loading forecast:', error);
    } finally {
      setLoading(false);
    }
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <TrendingUp className="w-12 h-12 text-slate-400 mx-auto mb-3" />
        <p className="text-slate-600">No products available for forecasting.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-slate-900">Demand Forecast</h2>
        <select
          value={selectedProduct}
          onChange={(e) => setSelectedProduct(e.target.value)}
          className="px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {products.map((product) => (
            <option key={product.id} value={product.id}>
              {product.name} ({product.sku})
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : forecastData ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                {forecastData.trend === 'up' && <TrendingUp className="w-5 h-5 text-blue-600" />}
                {forecastData.trend === 'down' && <TrendingDown className="w-5 h-5 text-blue-600" />}
                {forecastData.trend === 'stable' && <Minus className="w-5 h-5 text-blue-600" />}
                <span className="text-sm font-medium text-blue-900">Demand Trend</span>
              </div>
              <div className="text-2xl font-bold text-blue-900 capitalize">{forecastData.trend}</div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg p-6 border border-emerald-200">
              <div className="text-sm font-medium text-emerald-900 mb-2">Avg. Daily Usage</div>
              <div className="text-2xl font-bold text-emerald-900">
                {forecastData.avgDailyChange.toFixed(1)} units
              </div>
            </div>

            <div className={`rounded-lg p-6 border ${
              forecastData.daysUntilReorder < 7
                ? 'bg-gradient-to-br from-red-50 to-red-100 border-red-200'
                : 'bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200'
            }`}>
              <div className={`text-sm font-medium mb-2 ${
                forecastData.daysUntilReorder < 7 ? 'text-red-900' : 'text-amber-900'
              }`}>
                Days Until Reorder
              </div>
              <div className={`text-2xl font-bold ${
                forecastData.daysUntilReorder < 7 ? 'text-red-900' : 'text-amber-900'
              }`}>
                {forecastData.daysUntilReorder > 99 ? '99+' : forecastData.daysUntilReorder} days
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-lg p-6 border border-slate-200">
            <h3 className="text-sm font-semibold text-slate-900 mb-4">14-Day Stock Projection</h3>
            <div className="relative h-64">
              <div className="absolute inset-0 flex items-end justify-between gap-1">
                {forecastData.forecastedStock.map((stock, index) => {
                  const maxStock = forecastData.product.max_stock_level;
                  const height = (stock / maxStock) * 100;
                  const isLow = stock <= forecastData.product.min_stock_level;

                  return (
                    <div key={index} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full flex flex-col items-center">
                        <span className="text-xs font-medium text-slate-700 mb-1">
                          {Math.round(stock)}
                        </span>
                        <div
                          className={`w-full rounded-t transition-all ${
                            isLow ? 'bg-red-400' : 'bg-blue-400'
                          }`}
                          style={{ height: `${Math.max(height, 5)}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-500">D{index + 1}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="mt-4 flex items-center justify-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-400 rounded"></div>
                <span className="text-slate-600">Normal Stock</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-400 rounded"></div>
                <span className="text-slate-600">Low Stock</span>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-blue-900 mb-2">Recommendations</h4>
            <ul className="space-y-1 text-sm text-blue-800">
              {forecastData.daysUntilReorder < 7 && (
                <li>• Order stock immediately to avoid stockout</li>
              )}
              {forecastData.daysUntilReorder >= 7 && forecastData.daysUntilReorder < 14 && (
                <li>• Plan to reorder within the next week</li>
              )}
              {forecastData.trend === 'up' && (
                <li>• Demand is increasing - consider raising minimum stock level</li>
              )}
              {forecastData.trend === 'down' && (
                <li>• Demand is decreasing - review pricing or promotion strategies</li>
              )}
              {forecastData.avgDailyChange > 0 && (
                <li>
                  • Recommended reorder quantity: {Math.ceil(forecastData.avgDailyChange * 30)} units
                  (30-day supply)
                </li>
              )}
            </ul>
          </div>
        </div>
      ) : null}
    </div>
  );
}
