export interface Database {
  public: {
    Tables: {
      products: {
        Row: {
          id: string;
          name: string;
          sku: string;
          current_stock: number;
          min_stock_level: number;
          max_stock_level: number;
          unit_price: number;
          category: string;
          supplier: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['products']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['products']['Insert']>;
      };
      inventory_history: {
        Row: {
          id: string;
          product_id: string;
          quantity_change: number;
          stock_after: number;
          transaction_type: string;
          notes: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['inventory_history']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['inventory_history']['Insert']>;
      };
    };
  };
}

export type Product = Database['public']['Tables']['products']['Row'];
export type InventoryHistory = Database['public']['Tables']['inventory_history']['Row'];
